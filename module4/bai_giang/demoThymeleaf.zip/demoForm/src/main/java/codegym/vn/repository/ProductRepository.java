package codegym.vn.repository;

import codegym.vn.entity.Product;

public interface ProductRepository extends Repository<Product> {
}
